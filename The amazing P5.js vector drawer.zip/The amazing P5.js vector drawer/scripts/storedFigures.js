let storedFigures = {
    fiugreName1: "JSON",
    fiugreName2: "JSON",
    fiugreName3: "JSON",
    fiugreName4: "JSON",
}