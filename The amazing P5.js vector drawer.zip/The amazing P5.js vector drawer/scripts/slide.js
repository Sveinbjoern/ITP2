// Every configuration and option will be in a slide
//by default the slides are in the sidebarLeft or slidebarRight

function Slide (location, position, type){

    let x = location[0];
    let y = location[1];

    // slide should be in the bar location

    // slide should be the position element of that location

    // slide should be of the type type

}

